// src/pages/NewPost.jsx
import PostEditor from "../components/PostEditor/PostEditor";

function NewPost() {
    return <PostEditor isDarkMode={false} />
}

export default NewPost;